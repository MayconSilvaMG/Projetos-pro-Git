﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using VerdinhoBR.Dados;


namespace VerdinhoFront.Controllers
{
    public class CarroController : Controller
    {
        private readonly UsuarioContext _context;

        public CarroController(UsuarioContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Cadastro(VerdinhoBR.Models.Veiculo veiculo)
        {
            _context.Veiculo.Add(veiculo);
            return View();
        }
    }
}
