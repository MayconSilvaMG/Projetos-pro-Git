﻿using System.Collections.Generic;

namespace VerdinhoBR.Models
{   
    public class Pagamento
    {
        public int ClienteId { get; set; }
        public int FuncionarioId { get; set; }
        public int ServicoId { get; set; }

        public Cliente Cliente { get; set; }
        public Funcionario Funcionario { get; set; }
        public List<Servicos>  Servicos { get; set; }
        
    }
}
