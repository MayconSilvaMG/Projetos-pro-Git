﻿namespace VerdinhoBR.Models
{
    public class Funcionario : Usuario
    {
        public int FuncionarioId { get; set; }
    }
}
