﻿namespace VerdinhoBR.Models
{
    public class Servicos 
    {
        public int ServicosId { get; set; }
        public string Tipo { get; set; }
        public double Preco { get; set; }
        public Pagamento Pagamentos { get; set; }
        
    }
}
