﻿namespace VerdinhoBR.Models
{
    public class Cliente : Usuario
    {
        public int ClienteId { get; set; }
        
    }
}
