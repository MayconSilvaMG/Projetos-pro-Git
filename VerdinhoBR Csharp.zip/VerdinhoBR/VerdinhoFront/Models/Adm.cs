﻿using System.Collections.Generic;

namespace VerdinhoBR.Models
{
    public class Adm : Usuario
    {
       public List <Posto> Postos { get; set; }
    }
}
