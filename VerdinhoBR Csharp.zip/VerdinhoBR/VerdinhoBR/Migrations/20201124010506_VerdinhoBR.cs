﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

namespace VerdinhoBR.Migrations
{
    public partial class VerdinhoBR : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Usuario",
                columns: table => new
                {
                    Nome = table.Column<string>(type: "text", nullable: false),
                    Id = table.Column<int>(type: "integer", nullable: false),
                    Telefone = table.Column<double>(type: "double precision", nullable: false),
                    CPF = table.Column<int>(type: "integer", nullable: false),
                    Email = table.Column<string>(type: "text", nullable: false),
                    Login = table.Column<string>(type: "text", nullable: false),
                    clienteNome = table.Column<string>(type: "text", nullable: true),
                    clienteId = table.Column<int>(type: "integer", nullable: true),
                    clienteEmail = table.Column<string>(type: "text", nullable: true),
                    clienteCPF = table.Column<int>(type: "integer", nullable: true),
                    clienteLogin = table.Column<string>(type: "text", nullable: true),
                    clienteTelefone = table.Column<double>(type: "double precision", nullable: true),
                    Discriminator = table.Column<string>(type: "text", nullable: false),
                    ClienteId = table.Column<int>(type: "integer", nullable: true),
                    FuncionarioId = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Usuario", x => new { x.Nome, x.Id, x.Email, x.CPF, x.Login, x.Telefone });
                    table.ForeignKey(
                        name: "FK_Usuario_Usuario_clienteNome_clienteId_clienteEmail_clienteC~",
                        columns: x => new { x.clienteNome, x.clienteId, x.clienteEmail, x.clienteCPF, x.clienteLogin, x.clienteTelefone },
                        principalTable: "Usuario",
                        principalColumns: new[] { "Nome", "Id", "Email", "CPF", "Login", "Telefone" },
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Veiculo",
                columns: table => new
                {
                    VeiculoId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Modelo = table.Column<string>(type: "text", nullable: true),
                    Placa = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Veiculo", x => x.VeiculoId);
                });

            migrationBuilder.CreateTable(
                name: "Carteira",
                columns: table => new
                {
                    CarteiraId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    PagamentoBoleto = table.Column<int>(type: "integer", nullable: false),
                    PagamentoCredito = table.Column<int>(type: "integer", nullable: false),
                    PagamentoDebito = table.Column<int>(type: "integer", nullable: false),
                    ClienteNome = table.Column<string>(type: "text", nullable: true),
                    ClienteId = table.Column<int>(type: "integer", nullable: true),
                    ClienteEmail = table.Column<string>(type: "text", nullable: true),
                    ClienteCPF = table.Column<int>(type: "integer", nullable: true),
                    ClienteLogin = table.Column<string>(type: "text", nullable: true),
                    ClienteTelefone = table.Column<double>(type: "double precision", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Carteira", x => x.CarteiraId);
                    table.ForeignKey(
                        name: "FK_Carteira_Usuario_ClienteNome_ClienteId_ClienteEmail_Cliente~",
                        columns: x => new { x.ClienteNome, x.ClienteId, x.ClienteEmail, x.ClienteCPF, x.ClienteLogin, x.ClienteTelefone },
                        principalTable: "Usuario",
                        principalColumns: new[] { "Nome", "Id", "Email", "CPF", "Login", "Telefone" },
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Pagamento",
                columns: table => new
                {
                    ClienteId = table.Column<int>(type: "integer", nullable: false),
                    FuncionarioId = table.Column<int>(type: "integer", nullable: false),
                    ServicoId = table.Column<int>(type: "integer", nullable: false),
                    ClienteNome = table.Column<string>(type: "text", nullable: false),
                    ClienteId1 = table.Column<int>(type: "integer", nullable: false),
                    ClienteEmail = table.Column<string>(type: "text", nullable: false),
                    ClienteCPF = table.Column<int>(type: "integer", nullable: false),
                    ClienteLogin = table.Column<string>(type: "text", nullable: false),
                    ClienteTelefone = table.Column<double>(type: "double precision", nullable: false),
                    FuncionarioNome = table.Column<string>(type: "text", nullable: false),
                    FuncionarioId1 = table.Column<int>(type: "integer", nullable: false),
                    FuncionarioEmail = table.Column<string>(type: "text", nullable: false),
                    FuncionarioCPF = table.Column<int>(type: "integer", nullable: false),
                    FuncionarioLogin = table.Column<string>(type: "text", nullable: false),
                    FuncionarioTelefone = table.Column<double>(type: "double precision", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pagamento", x => new { x.ClienteId, x.FuncionarioId, x.ServicoId });
                    table.ForeignKey(
                        name: "FK_Pagamento_Usuario_ClienteNome_ClienteId1_ClienteEmail_Clien~",
                        columns: x => new { x.ClienteNome, x.ClienteId1, x.ClienteEmail, x.ClienteCPF, x.ClienteLogin, x.ClienteTelefone },
                        principalTable: "Usuario",
                        principalColumns: new[] { "Nome", "Id", "Email", "CPF", "Login", "Telefone" },
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Pagamento_Usuario_FuncionarioNome_FuncionarioId1_Funcionari~",
                        columns: x => new { x.FuncionarioNome, x.FuncionarioId1, x.FuncionarioEmail, x.FuncionarioCPF, x.FuncionarioLogin, x.FuncionarioTelefone },
                        principalTable: "Usuario",
                        principalColumns: new[] { "Nome", "Id", "Email", "CPF", "Login", "Telefone" },
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Posto",
                columns: table => new
                {
                    PostoId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Nome = table.Column<string>(type: "text", nullable: true),
                    Localizacao = table.Column<string>(type: "text", nullable: true),
                    AdmNome = table.Column<string>(type: "text", nullable: true),
                    AdmId = table.Column<int>(type: "integer", nullable: true),
                    AdmEmail = table.Column<string>(type: "text", nullable: true),
                    AdmCPF = table.Column<int>(type: "integer", nullable: true),
                    AdmLogin = table.Column<string>(type: "text", nullable: true),
                    AdmTelefone = table.Column<double>(type: "double precision", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Posto", x => x.PostoId);
                    table.ForeignKey(
                        name: "FK_Posto_Usuario_AdmNome_AdmId_AdmEmail_AdmCPF_AdmLogin_AdmTel~",
                        columns: x => new { x.AdmNome, x.AdmId, x.AdmEmail, x.AdmCPF, x.AdmLogin, x.AdmTelefone },
                        principalTable: "Usuario",
                        principalColumns: new[] { "Nome", "Id", "Email", "CPF", "Login", "Telefone" },
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Servicos",
                columns: table => new
                {
                    ServicosId = table.Column<int>(type: "integer", nullable: false),
                    Tipo = table.Column<string>(type: "text", nullable: false),
                    Preco = table.Column<double>(type: "double precision", nullable: false),
                    PagamentosClienteId = table.Column<int>(type: "integer", nullable: true),
                    PagamentosFuncionarioId = table.Column<int>(type: "integer", nullable: true),
                    PagamentosServicoId = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Servicos", x => new { x.ServicosId, x.Preco, x.Tipo });
                    table.ForeignKey(
                        name: "FK_Servicos_Pagamento_PagamentosClienteId_PagamentosFuncionari~",
                        columns: x => new { x.PagamentosClienteId, x.PagamentosFuncionarioId, x.PagamentosServicoId },
                        principalTable: "Pagamento",
                        principalColumns: new[] { "ClienteId", "FuncionarioId", "ServicoId" },
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ServicoPagamento",
                columns: table => new
                {
                    ServicoPagamentoId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    PagamentoId = table.Column<int>(type: "integer", nullable: false),
                    ServicoId = table.Column<int>(type: "integer", nullable: false),
                    PagamentoClienteId = table.Column<int>(type: "integer", nullable: false),
                    PagamentoFuncionarioId = table.Column<int>(type: "integer", nullable: false),
                    PagamentoServicoId = table.Column<int>(type: "integer", nullable: false),
                    ServicosId = table.Column<int>(type: "integer", nullable: true),
                    ServicosPreco = table.Column<double>(type: "double precision", nullable: true),
                    ServicosTipo = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ServicoPagamento", x => x.ServicoPagamentoId);
                    table.ForeignKey(
                        name: "FK_ServicoPagamento_Pagamento_PagamentoClienteId_PagamentoFunc~",
                        columns: x => new { x.PagamentoClienteId, x.PagamentoFuncionarioId, x.PagamentoServicoId },
                        principalTable: "Pagamento",
                        principalColumns: new[] { "ClienteId", "FuncionarioId", "ServicoId" },
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ServicoPagamento_Servicos_ServicosId_ServicosPreco_Servicos~",
                        columns: x => new { x.ServicosId, x.ServicosPreco, x.ServicosTipo },
                        principalTable: "Servicos",
                        principalColumns: new[] { "ServicosId", "Preco", "Tipo" },
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Carteira_ClienteNome_ClienteId_ClienteEmail_ClienteCPF_Clie~",
                table: "Carteira",
                columns: new[] { "ClienteNome", "ClienteId", "ClienteEmail", "ClienteCPF", "ClienteLogin", "ClienteTelefone" });

            migrationBuilder.CreateIndex(
                name: "IX_Pagamento_ClienteNome_ClienteId1_ClienteEmail_ClienteCPF_Cl~",
                table: "Pagamento",
                columns: new[] { "ClienteNome", "ClienteId1", "ClienteEmail", "ClienteCPF", "ClienteLogin", "ClienteTelefone" });

            migrationBuilder.CreateIndex(
                name: "IX_Pagamento_FuncionarioNome_FuncionarioId1_FuncionarioEmail_F~",
                table: "Pagamento",
                columns: new[] { "FuncionarioNome", "FuncionarioId1", "FuncionarioEmail", "FuncionarioCPF", "FuncionarioLogin", "FuncionarioTelefone" });

            migrationBuilder.CreateIndex(
                name: "IX_Posto_AdmNome_AdmId_AdmEmail_AdmCPF_AdmLogin_AdmTelefone",
                table: "Posto",
                columns: new[] { "AdmNome", "AdmId", "AdmEmail", "AdmCPF", "AdmLogin", "AdmTelefone" });

            migrationBuilder.CreateIndex(
                name: "IX_ServicoPagamento_PagamentoClienteId_PagamentoFuncionarioId_~",
                table: "ServicoPagamento",
                columns: new[] { "PagamentoClienteId", "PagamentoFuncionarioId", "PagamentoServicoId" });

            migrationBuilder.CreateIndex(
                name: "IX_ServicoPagamento_ServicosId_ServicosPreco_ServicosTipo",
                table: "ServicoPagamento",
                columns: new[] { "ServicosId", "ServicosPreco", "ServicosTipo" });

            migrationBuilder.CreateIndex(
                name: "IX_Servicos_PagamentosClienteId_PagamentosFuncionarioId_Pagame~",
                table: "Servicos",
                columns: new[] { "PagamentosClienteId", "PagamentosFuncionarioId", "PagamentosServicoId" });

            migrationBuilder.CreateIndex(
                name: "IX_Usuario_clienteNome_clienteId_clienteEmail_clienteCPF_clien~",
                table: "Usuario",
                columns: new[] { "clienteNome", "clienteId", "clienteEmail", "clienteCPF", "clienteLogin", "clienteTelefone" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Carteira");

            migrationBuilder.DropTable(
                name: "Posto");

            migrationBuilder.DropTable(
                name: "ServicoPagamento");

            migrationBuilder.DropTable(
                name: "Veiculo");

            migrationBuilder.DropTable(
                name: "Servicos");

            migrationBuilder.DropTable(
                name: "Pagamento");

            migrationBuilder.DropTable(
                name: "Usuario");
        }
    }
}
