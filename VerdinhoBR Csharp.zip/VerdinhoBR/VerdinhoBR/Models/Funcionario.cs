﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VerdinhoBR.Models
{
    public class Funcionario : Usuario
    {
        public int FuncionarioId { get; set; }
    }
}
