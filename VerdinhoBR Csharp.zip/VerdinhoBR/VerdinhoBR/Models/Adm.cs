﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VerdinhoBR.Models
{
    public class Adm : Usuario
    {
       public List <Posto> Postos { get; set; }
    }
}
