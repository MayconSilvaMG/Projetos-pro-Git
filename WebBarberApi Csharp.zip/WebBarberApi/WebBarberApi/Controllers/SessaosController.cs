﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebBarberApi.Dados;
using WebBarberApi.Models;

namespace WebBarberApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SessaosController : ControllerBase
    {
        private readonly WebBarberContext _context;

        public SessaosController(WebBarberContext context)
        {
            _context = context;
        }

        // GET: api/Sessaos
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Sessao>>> GetSessao()
        {
            return await _context.Sessao.ToListAsync();
        }

        // GET: api/Sessaos/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Sessao>> GetSessao(int id)
        {
            var sessao = await _context.Sessao.FindAsync(id);

            if (sessao == null)
            {
                return NotFound();
            }

            return sessao;
        }

        // PUT: api/Sessaos/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSessao(int id, Sessao sessao)
        {
            if (id != sessao.Id)
            {
                return BadRequest();
            }

            _context.Entry(sessao).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SessaoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Sessaos
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Sessao>> PostSessao(Sessao sessao)
        {
            _context.Sessao.Add(sessao);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetSessao", new { id = sessao.Id }, sessao);
        }

        // DELETE: api/Sessaos/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Sessao>> DeleteSessao(int id)
        {
            var sessao = await _context.Sessao.FindAsync(id);
            if (sessao == null)
            {
                return NotFound();
            }

            _context.Sessao.Remove(sessao);
            await _context.SaveChangesAsync();

            return sessao;
        }

        private bool SessaoExists(int id)
        {
            return _context.Sessao.Any(e => e.Id == id);
        }
    }
}
