﻿using Microsoft.EntityFrameworkCore;
using WebBarberApi.Models;

namespace WebBarberApi.Dados
{
    public class WebBarberContext : DbContext
    {
        public WebBarberContext(DbContextOptions<WebBarberContext> options) : base(options)
        {
        }

   
        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Barbeiro> Barbeiros { get; set; }
        public DbSet<Sessao> Sessao { get; set; }
    }
}
