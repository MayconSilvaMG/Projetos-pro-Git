﻿using System;

namespace WebBarberApi.Models
{
    public class Sessao
    {
        public int Id { get; set; }
        public DateTime Data { get; set; }
        public DateTime horaDia { get; set; }
    }
}
