﻿using System;
using System.Collections.Generic;

namespace WebBarberApi.Models
{
    public class Cliente
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string CPF { get; set; }
        public String Telefone { get; set; }
        public DateTime Horario { get; set; }
       
        public List<Sessao> Sessaos { get; set; }
       
    }
}
