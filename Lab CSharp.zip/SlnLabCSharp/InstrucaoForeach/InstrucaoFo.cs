﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstrucaoForeach
{
    class InstrucaoFo
    {
        static void Main(string[] args)
        {
            foreach (string s in args){
                Console.WriteLine(s);
            }
            Console.WriteLine("\nSeu programa funcionou com êxito, \nDigite uma tecla para sair!!!");
            Console.ReadKey();
        }
    }
}
