﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acme.Collections
{
    public class Stack
    {
        #region Variaveis
        Entry top;
        #endregion

        #region Métodos
        public void Push(object date)
        {
            top = new Entry(top, date);
        }

        public object Pop()
        {
            if (top == null) 
                throw new InvalidOperationException();
            
            object result = top.date;
            top = top.next;
            
            return result;
        }

        public object Older()
        {
            if (top == null) throw new InvalidOperationException();


            Entry topAuxiliar = top;

            while(topAuxiliar.next != null)
            {
                topAuxiliar = topAuxiliar.next;
            }
            return topAuxiliar.date;

        }

        #endregion

        #region Classe para armazenar o objeto a ser empilhado
        private class Entry
        {
            //Variável que aponta para o próximo da pilha.
            public Entry next;
            
            //Variável para armazenamento de dados.
            public object date;
           
            //Criando o construtor.
            public Entry (Entry next, object date){
                this.next = next;
                this.date = date;
            }
        }
        #endregion
    }
}
