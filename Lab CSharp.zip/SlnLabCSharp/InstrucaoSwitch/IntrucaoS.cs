﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstrucaoSwitch
{
    class IntrucaoS
    {
        static void Main(string[] args)
        {
            int n = args.Length;

            switch (n){
                case 0:
                    Console.WriteLine("No arguments");
                    break;

                case 1:
                    Console.WriteLine("One Arguments");
                    break;

                default:
                    Console.WriteLine("{0} arguments ", n);
                    break;
            }
            Console.WriteLine("\nSeu programa funcionou com êxito, \nDigite uma tecla para sair!!!");
            Console.ReadKey();
        }
    }
}
