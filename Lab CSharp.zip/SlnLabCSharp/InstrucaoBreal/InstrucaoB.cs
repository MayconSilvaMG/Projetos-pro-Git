﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstrucaoBreal
{
    class InstrucaoB
    {
        static void Main()
        {
            while (true){
                string s = Console.ReadLine();

                if (s == null) break;
                Console.WriteLine(s);
            }   
        }
    }
}
