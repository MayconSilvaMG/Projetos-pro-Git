﻿using Acme.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pilha
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack pilha = new Stack();

            pilha.Push("B");
            pilha.Push("A");
            pilha.Push("N");
            pilha.Push("A");
            pilha.Push("N");
            pilha.Push("A");
            
            /*
            Console.WriteLine(pilha.Pop());
            Console.WriteLine(pilha.Pop());
            Console.WriteLine(pilha.Pop());
            Console.WriteLine(pilha.Pop());
            Console.WriteLine(pilha.Pop());
            Console.WriteLine(pilha.Pop());*/

            Console.Write("\nO primeiro empilhado foi: ");
            Console.WriteLine(pilha.Older());



            Console.WriteLine("\n Digite uma tecla para sair!!");
            Console.ReadKey();
        }
    }
}
