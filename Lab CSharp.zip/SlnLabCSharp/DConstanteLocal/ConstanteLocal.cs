﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DConstanteLocal
{
    class ConstanteLocal
    {
          static void Main()
        {
            const float pi = 3.1415927f;
            const int r = 25;

            Console.WriteLine(pi * r * r);

            Console.WriteLine("\nSeu programa funcionou com êxito, \nDigite uma tecla para sair!!!");
            Console.ReadKey();
        }
    }
}
