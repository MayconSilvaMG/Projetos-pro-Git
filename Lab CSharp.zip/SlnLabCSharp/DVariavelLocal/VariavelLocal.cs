﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVariavelLocal
{
    class VariavelLocal
    {
          static void Main()
        {
            int a;
            int b = 2, c = 3;
            a = 1;


            Console.WriteLine(a + b + c);
            
            Console.WriteLine("\nSeu programa funcionou com êxito, \nDigite uma tecla para sair!!!");
            Console.ReadKey();
        }


    }
}
