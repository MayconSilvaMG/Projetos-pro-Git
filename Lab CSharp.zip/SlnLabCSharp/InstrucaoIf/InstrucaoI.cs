﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstrucaoIf
{
    class InstrucaoI
    {
        static void Main(string[] args)
        {
            if (args.Length == 0){
                Console.WriteLine("No arguments!");
            }
            else{
                Console.WriteLine("One or more arguments");
            }
            Console.WriteLine("\nSeu programa funcionou com êxito, \nDigite uma tecla para sair!!!");
            Console.ReadKey();
        }
    }
}
