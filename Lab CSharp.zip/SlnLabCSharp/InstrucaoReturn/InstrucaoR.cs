﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstrucaoReturn
{
    class InstrucaoR
    {
        static int Add(int a, int b)
        {
            return a + b;
        }

        static void Main()
        {
            Console.WriteLine(Add(1, 2));
            Console.WriteLine("\nSeu programa funcionou com êxito, \nDigite uma tecla para sair!!!");
            Console.ReadKey();
            return;
        }
    }
}
