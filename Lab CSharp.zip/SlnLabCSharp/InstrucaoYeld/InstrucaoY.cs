﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstrucaoYeld
{
    class InstrucaoY
    {
        static IEnumerable<int> Range(int from, int to)
        {
            for (int i = from; i < to; i++){
                yield return i;
            }
            yield break;
        }

        static void Main()
        {
            foreach (int x in Range(-10, 10)){
                Console.WriteLine(x);
            }
            
            Console.WriteLine("\nSeu programa funcionou com êxito, \nDigite uma tecla para sair!!!");
            Console.ReadKey();
        }
    }
}
