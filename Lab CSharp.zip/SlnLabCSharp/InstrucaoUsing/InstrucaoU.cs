﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstrucaoUsing
{
    class InstrucaoU
    {
        static void Main()
        {
            using (TextWriter w = File.CreateText("test.txt"))
            {
                w.WriteLine("Line one");
                w.WriteLine("Line two");
                w.WriteLine("Line three");
                
                Console.WriteLine("\nSeu programa funcionou com êxito, \nDigite uma tecla para sair!!!");
                Console.ReadKey();
            }
        }
    }
}
