﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstrucaoWhile
{
    class InstrucaoW
    {
        static void Main(string[] args)
        {
            int i = 0;

            while(i < args.Length){
                Console.WriteLine(args[i]);
                i++;
            }
            Console.WriteLine("\nSeu programa funcionou com êxito, \nDigite uma tecla para sair!!!");
            Console.ReadKey();
        }
    }
}
