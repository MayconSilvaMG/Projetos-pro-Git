﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstrucaoExpressao
{
    class InstrucaoE
    {
        static void Main()
        {
            int i;

            i = 123;    //Expression statement 
            Console.WriteLine(i);    //Expression statement 
            
            i++;    //Expression statement 
            Console.WriteLine(i);   //Expression statement 

            Console.WriteLine("\nSeu programa funcionou com êxito, \nDigite uma tecla para sair!!!");
            Console.ReadKey();

        }
    }
}
