﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstrucaoDo
{
    class InstrucaoD
    {
        static void Main()
        {
            string s;

            do
            {
                s = Console.ReadLine();
                if (s != null) Console.WriteLine(s);
            } while (s != null);

        }
    }
}
