﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            //Comando para escrever uma string no console
            Console.WriteLine("Hello World!!");

            Console.WriteLine("Press any key to exit");

            //Comando para ler uma tecla digitada
            Console.ReadLine();
        }
    }
}
