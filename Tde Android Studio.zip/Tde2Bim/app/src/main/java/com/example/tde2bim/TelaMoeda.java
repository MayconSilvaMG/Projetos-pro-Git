package com.example.tde2bim;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class TelaMoeda extends AppCompatActivity {

    EditText EdtSoma,EdtResult;
    Button BtnSoma;
    String Kevyn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_moeda);

        EdtSoma=findViewById(R.id.edtSoma);
        EdtResult=findViewById(R.id.edtResult);
        BtnSoma=findViewById(R.id.btnSoma);

        BtnSoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double ValorWon=Double.parseDouble(EdtSoma.getText().toString());

                double ResultD= ValorWon * 0.085;

                DecimalFormat diminuidor=new DecimalFormat("0.000");
                Kevyn=diminuidor.format(ResultD);
                EdtResult.setText(String.valueOf(ResultD));
            }
        });
    }
}