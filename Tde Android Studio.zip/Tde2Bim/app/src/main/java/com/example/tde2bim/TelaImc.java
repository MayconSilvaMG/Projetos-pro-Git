package com.example.tde2bim;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class TelaImc extends AppCompatActivity {

    Button BtnAcao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_imc);
        final Float[] IMC = new Float[1];
        BtnAcao=findViewById(R.id.btnAcao);
        BtnAcao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText Peso=(EditText) findViewById(R.id.edtPeso);
                EditText Altura=(EditText) findViewById(R.id.edtAltura);
                EditText Resultado=(EditText) findViewById(R.id.edtResultado);
                EditText Descricao=(EditText) findViewById(R.id.edtDescricao);

                int Kg= Integer.parseInt(Peso.getText().toString());
                float Metros= Float.parseFloat(Altura.getText().toString());

              IMC[0] = Kg/(Metros*Metros);

                if (IMC[0]<18.5){
                    Resultado.setText(IMC[0]+"");
                    Descricao.setText("TU TÁ MUITOOO MAGRO RAPAZ");
                }else {
                    if (IMC[0]<25){
                        Resultado.setText(IMC[0]+"");
                        Descricao.setText("BOA SOLDADOOOO, CONTINUE ASSIM");
                    }
                    else {
                        if (IMC[0]<30){
                            Resultado.setText(IMC[0]+"");
                            Descricao.setText("TOME CUIDADO, TU TA COM SOBREPESO");
                        }

                        else {
                            Resultado.setText(IMC[0]+"");
                            Descricao.setText("AIII NÃO, TU TÁ OBESO, BORA FAZER EXERCICIO");
                        }
                    } } }
        });
    }
}