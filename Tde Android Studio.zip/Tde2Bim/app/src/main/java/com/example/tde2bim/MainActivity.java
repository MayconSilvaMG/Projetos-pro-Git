package com.example.tde2bim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button BtnImc, BtnJogo, BtnMoeda;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BtnImc=findViewById(R.id.btnImc);
        BtnJogo=findViewById(R.id.btnJogo);
        BtnMoeda=findViewById(R.id.btnMoeda);

        BtnMoeda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telamoeda=new Intent(getApplicationContext(),TelaMoeda.class);
                    startActivity(telamoeda );
            }
        });
        BtnJogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent teladado=new Intent(getApplicationContext(),TelaDado.class);
                    startActivity(teladado );
            }
        });
        BtnImc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaimc=new Intent(getApplicationContext(),TelaImc.class);
                    startActivity(telaimc);
            }
        });
    }
}