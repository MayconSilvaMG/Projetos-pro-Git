package com.example.tde2bim;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class TelaDado extends AppCompatActivity {

    Button BtnJogar;
    ImageView ImagemUm,ImagemDois,ImagemTres,ImagemQuatro,ImagemCinco,ImagemSeis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_dado);
        BtnJogar=findViewById(R.id.btnJogar);
        ImagemUm=findViewById(R.id.imgUm);
        ImagemDois=findViewById(R.id.imgDois);
        ImagemTres=findViewById(R.id.imgTres);
        ImagemQuatro=findViewById(R.id.imgQuatro);
        ImagemCinco=findViewById(R.id.imgCinco);
        ImagemSeis=findViewById(R.id.imgSeis);
    }

    public void Joguinho(View v){
        int Jogo;

        Random random = new Random();
        Jogo = random.nextInt(6);

        if (Jogo == 0){
            ImagemUm.setVisibility(View.VISIBLE);
            ImagemDois.setVisibility(View.INVISIBLE);
            ImagemTres.setVisibility(View.INVISIBLE);
            ImagemQuatro.setVisibility(View.INVISIBLE);
            ImagemCinco.setVisibility(View.INVISIBLE);
            ImagemSeis.setVisibility(View.INVISIBLE);
        }
        if (Jogo == 1){
            ImagemUm.setVisibility(View.INVISIBLE);
            ImagemDois.setVisibility(View.VISIBLE);
            ImagemTres.setVisibility(View.INVISIBLE);
            ImagemQuatro.setVisibility(View.INVISIBLE);
            ImagemCinco.setVisibility(View.INVISIBLE);
            ImagemSeis.setVisibility(View.INVISIBLE);
        }
        if (Jogo == 2){
            ImagemUm.setVisibility(View.INVISIBLE);
            ImagemDois.setVisibility(View.INVISIBLE);
            ImagemTres.setVisibility(View.VISIBLE);
            ImagemQuatro.setVisibility(View.INVISIBLE);
            ImagemCinco.setVisibility(View.INVISIBLE);
            ImagemSeis.setVisibility(View.INVISIBLE);
        }
        if (Jogo == 3){
            ImagemUm.setVisibility(View.INVISIBLE);
            ImagemDois.setVisibility(View.INVISIBLE);
            ImagemTres.setVisibility(View.INVISIBLE);
            ImagemQuatro.setVisibility(View.VISIBLE);
            ImagemCinco.setVisibility(View.INVISIBLE);
            ImagemSeis.setVisibility(View.INVISIBLE);
        }
        if (Jogo == 4){
            ImagemUm.setVisibility(View.INVISIBLE);
            ImagemDois.setVisibility(View.INVISIBLE);
            ImagemTres.setVisibility(View.INVISIBLE);
            ImagemQuatro.setVisibility(View.INVISIBLE);
            ImagemCinco.setVisibility(View.VISIBLE);
            ImagemSeis.setVisibility(View.INVISIBLE);
        }
        if (Jogo == 5){
            ImagemUm.setVisibility(View.INVISIBLE);
            ImagemDois.setVisibility(View.INVISIBLE);
            ImagemTres.setVisibility(View.INVISIBLE);
            ImagemQuatro.setVisibility(View.INVISIBLE);
            ImagemCinco.setVisibility(View.INVISIBLE);
            ImagemSeis.setVisibility(View.VISIBLE);
        }
    }
}