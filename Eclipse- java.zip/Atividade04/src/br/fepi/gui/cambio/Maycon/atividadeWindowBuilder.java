package br.fepi.gui.cambio.Maycon;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Window.Type;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import java.awt.SystemColor;
import javax.swing.ImageIcon;

public class atividadeWindowBuilder extends JFrame {

	private JPanel contentPane;
	/**
	 * @wbp.nonvisual location=-19,-31
	 */
	private final JLabel label = new JLabel("New label");
	private JTextField txValorR;
	private JComboBox comboBox;
	private JButton btnNewButton;
	private JLabel lblValortxt;
	private Float Result;
	private JLabel lblNewLabel_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					atividadeWindowBuilder frame = new atividadeWindowBuilder();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public atividadeWindowBuilder() {
		setModalExclusionType(ModalExclusionType.APPLICATION_EXCLUDE);
		setFont(new Font("Arial Black", Font.BOLD, 12));
		setBackground(new Color(0, 0, 0));
		setTitle("Convers\u00E3o de moeda");
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(atividadeWindowBuilder.class.getResource("/br/fepi/gui/cambio/Maycon/AA.png")));
		setForeground(new Color(0, 0, 0));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(204, 0, 0));
		contentPane.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, Color.BLACK, null, null, null));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Valor em reais(R$)");
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 12));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBackground(Color.BLACK);
		lblNewLabel.setBounds(10, 11, 127, 28);
		contentPane.add(lblNewLabel);
		
		txValorR = new JTextField();
		txValorR.setBackground(new Color(204, 0, 0));
		txValorR.setForeground(new Color(0, 0, 0));
		txValorR.setBounds(20, 42, 91, 28);
		contentPane.add(txValorR);
		txValorR.setColumns(10);
		
		comboBox = new JComboBox();
		comboBox.setForeground(new Color(0, 0, 0));
		comboBox.setBackground(new Color(204, 0, 0));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Won", "Peso", "Euro", "Comunismo"}));
		comboBox.setBounds(170, 41, 68, 29);
		contentPane.add(comboBox);
		
		btnNewButton = new JButton("Converter");
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Realvalor = txValorR.getText();
				Float conversor = Float.parseFloat(Realvalor); 
				
				int index = comboBox.getSelectedIndex();
				
					if (index == 0) {
						Result = conversor * 212.86f;
						lblValortxt.setText("Valor convertido: " + Result + " Won");
						lblNewLabel_1.setVisible(false);
					}
					if (index == 1) {
						Result = conversor * 17.71f;
						lblValortxt.setText("Valor convertido: " + Result + " Peso");
						lblNewLabel_1.setVisible(false);
					}
					if (index == 2) {
						Result = conversor * 0.16f;
						lblValortxt.setText("Valor convertido: " + Result + " Euro");
						lblNewLabel_1.setVisible(false);
					}
					if (index == 3) {
						lblValortxt.setText("TUDO NOSSO!");
						lblNewLabel_1.setVisible(true);
					}
			}
		});
		btnNewButton.setBounds(274, 41, 108, 29);
		contentPane.add(btnNewButton);
		
		lblValortxt = new JLabel("Valor convertido:");
		lblValortxt.setForeground(new Color(0, 0, 0));
		lblValortxt.setBackground(new Color(250, 235, 215));
		lblValortxt.setFont(new Font("Arial Black", Font.BOLD | Font.ITALIC, 13));
		lblValortxt.setBounds(10, 192, 414, 52);
		contentPane.add(lblValortxt);
		
		lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setVisible(false);
		lblNewLabel_1.setIcon(new ImageIcon(atividadeWindowBuilder.class.getResource("/br/fepi/gui/cambio/Maycon/Sem_Titulo-1.png")));
		lblNewLabel_1.setBounds(10, 81, 424, 136);
		contentPane.add(lblNewLabel_1);
	}
}
