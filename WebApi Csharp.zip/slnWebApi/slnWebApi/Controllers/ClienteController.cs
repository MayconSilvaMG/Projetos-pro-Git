﻿using System;
using System.Collections.Generic;
using System.Linq;
using slnWebApi.Models;
using slnWebApi.Repositorio;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace slnWebApi.Controllers
{
    public class ClienteController:ApiController
    {
        static readonly IClienteRepositorio _repositorio = new ClienteRepositorio();

        public IEnumerable<Cliente> GetAllClientes()
        {
            return _repositorio.GetAll();
        }

        public Cliente GetClientes(int id)
        {
            var cliente = _repositorio.Get(id);

            if (cliente == null)
                throw new HttpResponseException(HttpStatusCode.NotFound);

            return cliente;
        }

        public IEnumerable<Cliente> GetClientesPorNacionalidade(string nacionalidade)
        {
            return _repositorio.GetAll().Where(
                c => string.Equals(c.Nacionalidade, nacionalidade, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        public HttpResponseMessage PostCliente(Cliente cliente)
        {
            cliente = _repositorio.Add(cliente);

            var response = Request.CreateResponse<Cliente>(HttpStatusCode.Created, cliente);

            string uri = Url.Link("DefaultAPI", new { id = cliente.id });

            response.Headers.Location = new Uri(uri);

            return response;
        }

        public void PutCliente(int id, Cliente cliente)
        {
            cliente.id = id;

            if (!_repositorio.Update(cliente))
                throw new HttpResponseException(HttpStatusCode.NotFound);
        }

        public void DeleteCliente(int id)
        {
            Cliente cliente = _repositorio.Get(id);

            if (cliente == null)
                throw new HttpResponseException(HttpStatusCode.NotFound);

            _repositorio.Remove(id);
        }
    }
}