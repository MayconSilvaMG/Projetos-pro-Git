﻿using System;
using System.Collections.Generic;
using slnWebApi.Models;


namespace slnWebApi.Repositorio
{
    public class ClienteRepositorio:IClienteRepositorio
    {
        private List<Cliente> _clientes = new List<Cliente>();
        private int _nextId = 1;

        public ClienteRepositorio()
        {
            
            Add(new Cliente() { Nacionalidade="Americano", Nome="Steven Jobs", Email="steve@apple.com", Nascimento=new DateTime(1955, 2, 25) });
            Add(new Cliente() { Nacionalidade="Americano", Nome="Steven Wozniak", Email="woz@apple.com", Nascimento=new DateTime(1950, 8, 11) });
            Add(new Cliente() { Nacionalidade="Africano", Nome="Elon Musk", Email="emusk@spacex.com", Nascimento=new DateTime(1971, 7, 28) });
            Add(new Cliente() { Nacionalidade="Americano", Nome="Jeff Bezos", Email="jeff@amazon.com", Nascimento=new DateTime(1964, 1, 12) });
            Add(new Cliente() { Nacionalidade="Americano", Nome="Larry Ellison", Email="joeellison@orecle.com", Nascimento=new DateTime(1944, 8, 17) });
            Add(new Cliente() { Nacionalidade="Americano", Nome="Larry Page", Email="larry@google.com", Nascimento=new DateTime(1973, 3, 26) });
        }

        public Cliente Add(Cliente cliente)
        {
            if (cliente == null)
                throw new ArgumentException("Cliente nulo");
            cliente.id = _nextId++;
            _clientes.Add(cliente);
            return cliente;
        }

        public Cliente Get(int id)
        {
            return _clientes.Find(c => c.id == id);
        }
        public IEnumerable<Cliente> GetAll()
        {
            return _clientes;
        }
        public void Remove(int id)
        {
            _clientes.RemoveAll(c => c.id == id);
        }
        public bool Update(Cliente cliente)
        {
            if (cliente == null)
                throw new Exception("Cliente Nulo");

            int index = _clientes.FindIndex(c => c.id == cliente.id);
            if (index == -1)
                return false;
            
            _clientes.RemoveAt(index);
            
            _clientes.Add(cliente);

            return true;
        }

    }
}