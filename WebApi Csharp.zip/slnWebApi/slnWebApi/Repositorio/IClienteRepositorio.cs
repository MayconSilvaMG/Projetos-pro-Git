﻿using System.Collections.Generic;
using slnWebApi.Models;

namespace slnWebApi.Repositorio
{
    public interface IClienteRepositorio
    {
        IEnumerable<Cliente> GetAll();
        Cliente Get(int id);
        Cliente Add(Cliente cliente);
        void Remove(int id);
        bool Update(Cliente cliente);
    }
}
