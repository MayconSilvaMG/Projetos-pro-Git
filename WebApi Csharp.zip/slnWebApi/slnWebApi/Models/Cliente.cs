﻿using System;

namespace slnWebApi.Models
{
    public class Cliente
    {
        public Cliente()
        {
        }
        public int id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public DateTime Nascimento { get; set; }
        public string Nacionalidade { get; set; }

    }
}