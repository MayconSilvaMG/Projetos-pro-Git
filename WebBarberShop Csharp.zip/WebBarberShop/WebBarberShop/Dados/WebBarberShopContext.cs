﻿using Microsoft.EntityFrameworkCore;
using WebBarberShop.Models;

namespace WebBarberShop.Dados
{
    public class WebBarberShopContext : DbContext
    {
        public WebBarberShopContext( DbContextOptions<WebBarberShopContext> options) : base(options)
        {
        }

        protected override void OnModelCreating (ModelBuilder modelBuilder) 
        {
            modelBuilder.Entity<BarberCliente>()
                .HasKey(ac => new { ac.BarbeiroId, ac.ClienteId });
            
            modelBuilder.Entity<BarberSessao>()
            .HasKey(ac => new { ac.BarbeiroId, ac.SessaoId });
        }

        public DbSet <Barbeiro> Barbeiros { get; set; }
        public DbSet<Sessao> Sessaos { get; set; }
        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<BarberCliente> BarberClientes { get; set; }
        public DbSet<BarberSessao> BarberSessaos { get; set; }
    }
}
 