﻿namespace WebBarberShop.Models
{
    public class BarberSessao
    {
        public int BarbeiroId { get; set; }
        public int SessaoId { get; set; }

        public Barbeiro Barbeiro { get; set; }
        public Sessao Sessao { get; set; }
    }
}
