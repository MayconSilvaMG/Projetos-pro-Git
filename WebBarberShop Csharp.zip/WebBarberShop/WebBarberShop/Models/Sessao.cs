﻿using System;
using System.Collections.Generic;

namespace WebBarberShop.Models
{
    public class Sessao
    {
        public int Id { get; set; }
        public DateTime horaDoDia { get; set; }
        public DateTime Data { get; set; }

        public Cliente Cliente { get; set; }
        public Barbeiro Barbeiro { get; set; }

        public List<BarberSessao> BarberSessaos { get; set; }
    }
}
