﻿namespace WebBarberShop.Models
{
    public class BarberCliente
    {
        public int BarbeiroId { get; set; }
        public int ClienteId { get; set; }

        public Barbeiro Barbeiro { get; set; }
        public Cliente Cliente{ get; set; }
    }
}
