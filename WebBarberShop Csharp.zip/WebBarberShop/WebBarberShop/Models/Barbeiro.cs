﻿using System;
using System.Collections.Generic;

namespace WebBarberShop.Models
{
    public class Barbeiro
    {
        public int Id { get; set; }
        public string NomeBarber { get; set; }
        public string CpfBarber { get; set; }
        public DateTime HorarioDispo { get; set; }

        public List<BarberSessao> BarberSessaos { get; set; }
        public List<BarberCliente> BarberClientes { get; set; }
    }
}
