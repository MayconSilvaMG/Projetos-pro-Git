﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebBarberShop.Dados;
using WebBarberShop.Models;

namespace WebBarberShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BarberSessaosController : ControllerBase
    {
        private readonly WebBarberShopContext _context;

        public BarberSessaosController(WebBarberShopContext context)
        {
            _context = context;
        }

        // GET: api/BarberSessaos
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BarberSessao>>> GetBarberSessaos()
        {
            return await _context.BarberSessaos.ToListAsync();
        }

        // GET: api/BarberSessaos/5
        [HttpGet("{id}")]
        public async Task<ActionResult<BarberSessao>> GetBarberSessao(int id)
        {
            var barberSessao = await _context.BarberSessaos.FindAsync(id);

            if (barberSessao == null)
            {
                return NotFound();
            }

            return barberSessao;
        }

        // PUT: api/BarberSessaos/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBarberSessao(int id, BarberSessao barberSessao)
        {
            if (id != barberSessao.BarbeiroId)
            {
                return BadRequest();
            }

            _context.Entry(barberSessao).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BarberSessaoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/BarberSessaos
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<BarberSessao>> PostBarberSessao(BarberSessao barberSessao)
        {
            _context.BarberSessaos.Add(barberSessao);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (BarberSessaoExists(barberSessao.BarbeiroId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetBarberSessao", new { id = barberSessao.BarbeiroId }, barberSessao);
        }

        // DELETE: api/BarberSessaos/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<BarberSessao>> DeleteBarberSessao(int id)
        {
            var barberSessao = await _context.BarberSessaos.FindAsync(id);
            if (barberSessao == null)
            {
                return NotFound();
            }

            _context.BarberSessaos.Remove(barberSessao);
            await _context.SaveChangesAsync();

            return barberSessao;
        }

        private bool BarberSessaoExists(int id)
        {
            return _context.BarberSessaos.Any(e => e.BarbeiroId == id);
        }
    }
}
