﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebBarberShop.Dados;
using WebBarberShop.Models;

namespace WebBarberShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BarbeirosController : ControllerBase
    {
        private readonly WebBarberShopContext _context;

        public BarbeirosController(WebBarberShopContext context)
        {
            _context = context;
        }

        // GET: api/Barbeiroes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Barbeiro>>> GetBarbeiros()
        {
            return await _context.Barbeiros.ToListAsync();
        }

        // GET: api/Barbeiroes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Barbeiro>> GetBarbeiro(int id)
        {
            var barbeiro = await _context.Barbeiros.FindAsync(id);

            if (barbeiro == null)
            {
                return NotFound();
            }

            return barbeiro;
        }

        // PUT: api/Barbeiroes/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBarbeiro(int id, Barbeiro barbeiro)
        {
            if (id != barbeiro.Id)
            {
                return BadRequest();
            }

            _context.Entry(barbeiro).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BarbeiroExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Barbeiroes
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Barbeiro>> PostBarbeiro(Barbeiro barbeiro)
        {
            _context.Barbeiros.Add(barbeiro);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetBarbeiro", new { id = barbeiro.Id }, barbeiro);
        }

        // DELETE: api/Barbeiroes/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Barbeiro>> DeleteBarbeiro(int id)
        {
            var barbeiro = await _context.Barbeiros.FindAsync(id);
            if (barbeiro == null)
            {
                return NotFound();
            }

            _context.Barbeiros.Remove(barbeiro);
            await _context.SaveChangesAsync();

            return barbeiro;
        }

        private bool BarbeiroExists(int id)
        {
            return _context.Barbeiros.Any(e => e.Id == id);
        }
    }
}
