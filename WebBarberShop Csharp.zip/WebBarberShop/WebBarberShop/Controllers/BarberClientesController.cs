﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebBarberShop.Dados;
using WebBarberShop.Models;

namespace WebBarberShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BarberClientesController : ControllerBase
    {
        private readonly WebBarberShopContext _context;

        public BarberClientesController(WebBarberShopContext context)
        {
            _context = context;
        }

        // GET: api/BarberClientes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BarberCliente>>> GetBarberClientes()
        {
            return await _context.BarberClientes.ToListAsync();
        }

        // GET: api/BarberClientes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<BarberCliente>> GetBarberCliente(int id)
        {
            var barberCliente = await _context.BarberClientes.FindAsync(id);

            if (barberCliente == null)
            {
                return NotFound();
            }

            return barberCliente;
        }

        // PUT: api/BarberClientes/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBarberCliente(int id, BarberCliente barberCliente)
        {
            if (id != barberCliente.BarbeiroId)
            {
                return BadRequest();
            }

            _context.Entry(barberCliente).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BarberClienteExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/BarberClientes
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<BarberCliente>> PostBarberCliente(BarberCliente barberCliente)
        {
            _context.BarberClientes.Add(barberCliente);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (BarberClienteExists(barberCliente.BarbeiroId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetBarberCliente", new { id = barberCliente.BarbeiroId }, barberCliente);
        }

        // DELETE: api/BarberClientes/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<BarberCliente>> DeleteBarberCliente(int id)
        {
            var barberCliente = await _context.BarberClientes.FindAsync(id);
            if (barberCliente == null)
            {
                return NotFound();
            }

            _context.BarberClientes.Remove(barberCliente);
            await _context.SaveChangesAsync();

            return barberCliente;
        }

        private bool BarberClienteExists(int id)
        {
            return _context.BarberClientes.Any(e => e.BarbeiroId == id);
        }
    }
}
