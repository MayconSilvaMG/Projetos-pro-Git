﻿namespace ViewEscola
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.LbSC = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblCpf = new System.Windows.Forms.Label();
            this.lblRg = new System.Windows.Forms.Label();
            this.lblDataNasci = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblTel = new System.Windows.Forms.Label();
            this.dTPNasci = new System.Windows.Forms.DateTimePicker();
            this.cBFuncao = new System.Windows.Forms.ComboBox();
            this.lblFuncaoR = new System.Windows.Forms.Label();
            this.mTBTel = new System.Windows.Forms.MaskedTextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtRg = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.rBMasc = new System.Windows.Forms.RadioButton();
            this.rBFem = new System.Windows.Forms.RadioButton();
            this.rBOutro = new System.Windows.Forms.RadioButton();
            this.gBSexo = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.LISTA = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.mTBCpf = new System.Windows.Forms.MaskedTextBox();
            this.gBSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // LbSC
            // 
            this.LbSC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LbSC.AutoSize = true;
            this.LbSC.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbSC.Location = new System.Drawing.Point(118, 9);
            this.LbSC.Name = "LbSC";
            this.LbSC.Size = new System.Drawing.Size(295, 20);
            this.LbSC.TabIndex = 0;
            this.LbSC.Text = "Seja bem vindo ao nosso sistema de cadastro";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(17, 44);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(53, 20);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome: ";
            // 
            // lblCpf
            // 
            this.lblCpf.AutoSize = true;
            this.lblCpf.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCpf.Location = new System.Drawing.Point(17, 82);
            this.lblCpf.Name = "lblCpf";
            this.lblCpf.Size = new System.Drawing.Size(43, 20);
            this.lblCpf.TabIndex = 2;
            this.lblCpf.Text = "CPF: ";
            // 
            // lblRg
            // 
            this.lblRg.AutoSize = true;
            this.lblRg.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRg.Location = new System.Drawing.Point(17, 120);
            this.lblRg.Name = "lblRg";
            this.lblRg.Size = new System.Drawing.Size(28, 20);
            this.lblRg.TabIndex = 3;
            this.lblRg.Text = "RG";
            // 
            // lblDataNasci
            // 
            this.lblDataNasci.AutoSize = true;
            this.lblDataNasci.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataNasci.Location = new System.Drawing.Point(17, 244);
            this.lblDataNasci.Name = "lblDataNasci";
            this.lblDataNasci.Size = new System.Drawing.Size(131, 20);
            this.lblDataNasci.TabIndex = 4;
            this.lblDataNasci.Text = "Data de nascimento:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(17, 164);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(46, 20);
            this.lblEmail.TabIndex = 5;
            this.lblEmail.Text = "Email:";
            // 
            // lblTel
            // 
            this.lblTel.AutoSize = true;
            this.lblTel.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTel.Location = new System.Drawing.Point(17, 287);
            this.lblTel.Name = "lblTel";
            this.lblTel.Size = new System.Drawing.Size(65, 20);
            this.lblTel.TabIndex = 6;
            this.lblTel.Text = "Telefone:";
            // 
            // dTPNasci
            // 
            this.dTPNasci.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dTPNasci.Location = new System.Drawing.Point(154, 244);
            this.dTPNasci.Name = "dTPNasci";
            this.dTPNasci.Size = new System.Drawing.Size(287, 26);
            this.dTPNasci.TabIndex = 7;
            this.dTPNasci.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            // 
            // cBFuncao
            // 
            this.cBFuncao.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cBFuncao.FormattingEnabled = true;
            this.cBFuncao.Location = new System.Drawing.Point(208, 199);
            this.cBFuncao.Name = "cBFuncao";
            this.cBFuncao.Size = new System.Drawing.Size(193, 28);
            this.cBFuncao.TabIndex = 8;
            this.cBFuncao.SelectedIndexChanged += new System.EventHandler(this.cBFuncao_SelectedIndexChanged);
            // 
            // lblFuncaoR
            // 
            this.lblFuncaoR.AutoSize = true;
            this.lblFuncaoR.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFuncaoR.Location = new System.Drawing.Point(17, 199);
            this.lblFuncaoR.Name = "lblFuncaoR";
            this.lblFuncaoR.Size = new System.Drawing.Size(185, 20);
            this.lblFuncaoR.TabIndex = 9;
            this.lblFuncaoR.Text = "Selecione a função requerida";
            // 
            // mTBTel
            // 
            this.mTBTel.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mTBTel.Location = new System.Drawing.Point(77, 284);
            this.mTBTel.Mask = "(00) 00000- 0000";
            this.mTBTel.Name = "mTBTel";
            this.mTBTel.Size = new System.Drawing.Size(113, 26);
            this.mTBTel.TabIndex = 10;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(77, 158);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(253, 26);
            this.txtEmail.TabIndex = 11;
            // 
            // txtRg
            // 
            this.txtRg.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRg.Location = new System.Drawing.Point(77, 117);
            this.txtRg.Name = "txtRg";
            this.txtRg.Size = new System.Drawing.Size(189, 26);
            this.txtRg.TabIndex = 12;
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(77, 43);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(253, 26);
            this.txtNome.TabIndex = 14;
            // 
            // rBMasc
            // 
            this.rBMasc.AutoSize = true;
            this.rBMasc.Checked = true;
            this.rBMasc.Location = new System.Drawing.Point(6, 25);
            this.rBMasc.Name = "rBMasc";
            this.rBMasc.Size = new System.Drawing.Size(87, 24);
            this.rBMasc.TabIndex = 16;
            this.rBMasc.TabStop = true;
            this.rBMasc.Text = "Masculino";
            this.rBMasc.UseVisualStyleBackColor = true;
            // 
            // rBFem
            // 
            this.rBFem.AutoSize = true;
            this.rBFem.Location = new System.Drawing.Point(6, 51);
            this.rBFem.Name = "rBFem";
            this.rBFem.Size = new System.Drawing.Size(82, 24);
            this.rBFem.TabIndex = 17;
            this.rBFem.Text = "Feminino";
            this.rBFem.UseVisualStyleBackColor = true;
            // 
            // rBOutro
            // 
            this.rBOutro.AutoSize = true;
            this.rBOutro.Location = new System.Drawing.Point(6, 81);
            this.rBOutro.Name = "rBOutro";
            this.rBOutro.Size = new System.Drawing.Size(59, 24);
            this.rBOutro.TabIndex = 18;
            this.rBOutro.Text = "Outro";
            this.rBOutro.UseVisualStyleBackColor = true;
            // 
            // gBSexo
            // 
            this.gBSexo.Controls.Add(this.rBMasc);
            this.gBSexo.Controls.Add(this.rBOutro);
            this.gBSexo.Controls.Add(this.rBFem);
            this.gBSexo.Location = new System.Drawing.Point(77, 327);
            this.gBSexo.Name = "gBSexo";
            this.gBSexo.Size = new System.Drawing.Size(107, 110);
            this.gBSexo.TabIndex = 19;
            this.gBSexo.TabStop = false;
            this.gBSexo.Text = "Sexo";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.Location = new System.Drawing.Point(122, 521);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(177, 52);
            this.button1.TabIndex = 20;
            this.button1.Text = "Cadastrar/Alterar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // LISTA
            // 
            this.LISTA.FormattingEnabled = true;
            this.LISTA.ItemHeight = 20;
            this.LISTA.Location = new System.Drawing.Point(657, 3);
            this.LISTA.Name = "LISTA";
            this.LISTA.Size = new System.Drawing.Size(238, 424);
            this.LISTA.TabIndex = 22;
            this.LISTA.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.LISTA_MouseDoubleClick);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button2.Location = new System.Drawing.Point(534, 521);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(177, 52);
            this.button2.TabIndex = 23;
            this.button2.Text = "Limpar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button3.Location = new System.Drawing.Point(328, 521);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(177, 52);
            this.button3.TabIndex = 24;
            this.button3.Text = "Excluir";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // mTBCpf
            // 
            this.mTBCpf.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mTBCpf.Location = new System.Drawing.Point(77, 79);
            this.mTBCpf.Mask = "000.000.000 - 00";
            this.mTBCpf.Name = "mTBCpf";
            this.mTBCpf.Size = new System.Drawing.Size(113, 26);
            this.mTBCpf.TabIndex = 25;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(907, 662);
            this.Controls.Add(this.mTBCpf);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.LISTA);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.gBSexo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtRg);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.mTBTel);
            this.Controls.Add(this.lblFuncaoR);
            this.Controls.Add(this.cBFuncao);
            this.Controls.Add(this.dTPNasci);
            this.Controls.Add(this.lblTel);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblDataNasci);
            this.Controls.Add(this.lblRg);
            this.Controls.Add(this.lblCpf);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.LbSC);
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FEPI- Centro Universitário de Itajubá";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gBSexo.ResumeLayout(false);
            this.gBSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LbSC;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblCpf;
        private System.Windows.Forms.Label lblRg;
        private System.Windows.Forms.Label lblDataNasci;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblTel;
        private System.Windows.Forms.DateTimePicker dTPNasci;
        private System.Windows.Forms.ComboBox cBFuncao;
        private System.Windows.Forms.Label lblFuncaoR;
        private System.Windows.Forms.MaskedTextBox mTBTel;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtRg;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.RadioButton rBMasc;
        private System.Windows.Forms.RadioButton rBFem;
        private System.Windows.Forms.RadioButton rBOutro;
        private System.Windows.Forms.GroupBox gBSexo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox LISTA;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.MaskedTextBox mTBCpf;
    }
}

