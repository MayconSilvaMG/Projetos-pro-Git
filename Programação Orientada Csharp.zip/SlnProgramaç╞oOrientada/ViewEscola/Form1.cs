﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ViewEscola
{
    public partial class Form1 : Form
    {
        List<Pessoa> pessoas;
        public Form1()
        {
            InitializeComponent();

            pessoas = new List<Pessoa>();

            cBFuncao.Items.Add("Aluno");
            cBFuncao.Items.Add("Professor");
            cBFuncao.Items.Add("Responsável");
            cBFuncao.Items.Add("Secretário (a)");

            cBFuncao.SelectedIndex= 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //Selecionar a função que deseja
        private void cBFuncao_SelectedIndexChanged(object sender, EventArgs e)
        {
        
        }

        //Botão Cadastrar/Alterar
        private void button1_Click(object sender, EventArgs e)
        {
            int index = -1;

            foreach (Pessoa pessoa in pessoas)
            {
                if(pessoa.Nome == txtNome.Text)
                {
                    index = pessoas.IndexOf(pessoa);
                }
            }

            if (txtNome.Text == "")
            {
                MessageBox.Show("Preencha o campo NOME! ");
                txtNome.Focus();
                return;
            }

            if (mTBCpf.Text == "")
            {
                MessageBox.Show("Preencha o campo CPF! ");
                mTBCpf.Focus();
                return;
            }

            if (txtEmail.Text == "")
            {
                MessageBox.Show("Preencha o campo EMAIL! ");
                txtEmail.Focus();
                return;
            }

            if (txtRg.Text == "")
            {
                MessageBox.Show("Preencha o campo RG! ");
                txtRg.Focus();
                return;
            }

            if (cBFuncao.Text == "")
            {
                MessageBox.Show("Defina uma função! ");
                txtRg.Focus();
                return;
            }

            if (dTPNasci.Text == "")
            {
                MessageBox.Show("Defina uma data de nascimento! ");
                txtRg.Focus();
                return;
            }

            if (mTBTel.Text == "(  )      - ")
            {
                MessageBox.Show("Preencha o campo Telefone! ");
                txtRg.Focus();
                return;
            }

            if (gBSexo.Text == "")
            {
                MessageBox.Show("Defina algum sexo! ");
                txtRg.Focus();
                return;
            }

            char sexo;

            if (rBMasc.Checked)
            {
                sexo = 'M';
            } 
            else if (rBFem.Checked)
            {
                sexo = 'F';
            }
            else
            {
                sexo = 'O';
            }

            Pessoa p = new Pessoa();
            p.Nome = txtNome.Text;
            p.Cpf = mTBCpf.Text;
            p.Email = txtEmail.Text;
            p.RG = txtRg.Text;
            p.SelecioneOpcao = cBFuncao.Text;
            p.DataNascimento = dTPNasci.MaxDate;
            p.Telefone = mTBTel.Text;
            p.Sexo = sexo;

            if (index < 0)
            {
                pessoas.Add(p);
            }
            else
            {
                pessoas[index] = p;
            }

            button2_Click_1(button2, EventArgs.Empty);

            Listar();
        } 

        //Uma ListBox
        private void Listar()
        {
            LISTA.Items.Clear();

            foreach (Pessoa pessoa in pessoas)
            {
                LISTA.Items.Add(pessoa.Nome);LISTA.Items.Add(pessoa.SelecioneOpcao);

            }
        }

        //Botão Limpar
        private void button2_Click_1(object sender, EventArgs e)
        {
            txtNome.Text = "";
            mTBCpf.Text = "";
            txtEmail.Text = "";
            txtRg.Text = "" ;
            cBFuncao.Text = "";
            rBMasc.Checked = true;
            rBFem.Checked = false;
            rBOutro.Checked = false;
            cBFuncao.SelectedIndex = 0;
            mTBTel.Text = "";
            txtNome.Focus();
        }

        //Botão Excluir
        private void button3_Click(object sender, EventArgs e)
        {
            int indice = LISTA.SelectedIndex;
            pessoas.RemoveAt(indice);
            Listar();
        }

        //Ação de duplo clique na listBox
        private void LISTA_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            int indice = LISTA.SelectedIndex;
            Pessoa p = pessoas[indice];

            txtNome.Text = p.Nome;
            dTPNasci.MaxDate = p.DataNascimento;
            cBFuncao.SelectedItem = p.SelecioneOpcao;
            txtEmail.Text = p.Telefone;
            mTBCpf.Text = p.Cpf;
            txtRg.Text = p.RG;
            mTBTel.Text = p.Telefone;

            switch (p.Sexo)
            {
                case 'M' :
                    rBMasc.Checked = true;
                    break;
                case 'F' :
                    rBFem.Checked = true;
                    break;
                default:
                    rBOutro.Checked = true;
                    break;
            }
        }
    }
}