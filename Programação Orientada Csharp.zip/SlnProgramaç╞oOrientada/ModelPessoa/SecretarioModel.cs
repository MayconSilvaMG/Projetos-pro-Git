﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelPessoa
{
    public class SecretarioModel:PessoaModel
    {
        #region Propriedades
        
        /* Numero da Carteira de Trabalho*/
        public int CTP { get; set; }

        #endregion

        #region Construtores
       
        public SecretarioModel()
        {

        }

        #endregion
    }
}
