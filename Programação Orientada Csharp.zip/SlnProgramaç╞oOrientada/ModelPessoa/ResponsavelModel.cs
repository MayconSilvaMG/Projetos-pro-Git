﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelPessoa
{
    public class ResponsavelModel:PessoaModel
    {
        #region Atributo
        
        private List<AlunoModel> _filhos;
        
        #endregion

        #region Propriedades
        
        public List<AlunoModel> Filhos { set; get; }
        
        #endregion
    }
}
