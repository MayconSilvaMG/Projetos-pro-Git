﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelPessoa
{
    public class ProfessorModel:PessoaModel
    {
        #region Propriedades
        
        //Número do diploma
        public int NumDiploma { get; set; }

        #endregion

    }
}
