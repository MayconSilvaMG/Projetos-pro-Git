﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelPessoa
{
    public class AlunoModel : PessoaModel
    {
        #region Atributos
       
        private int _matricula;
        private string _curso;

        #endregion
       
        #region Propriedades
        
        public int Matricula {get; set;}
        public string Curso{get; set;}

        #endregion

        #region Construtor
        
        public AlunoModel(string nome, int RG)
        {
            this.Nome = nome;
            this.RG = RG;
        }

        #endregion

    }
}
