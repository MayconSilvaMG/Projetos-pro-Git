﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelPessoa
{
    public abstract class PessoaModel
    {
        #region Atributos

        private string _nome;
        private string _email;
        private string _telefone;
        private string _cpf;
        private DateTime _dataNascimento;

        #endregion

        #region Propriedades

        public string Nome { get; set; }
        public string Email { get => _email; set => _email = value; }
        public string Telefone { get => _telefone; set => _telefone = value; }
        public string Cpf { get => _cpf; set => _cpf = value; }
        public DateTime DataNascimento { get => _dataNascimento; set => _dataNascimento = value; }
        public int RG { get; set; }
        public char Sexo { get; set; }
        public string SelecioneOpcao { get; set; }

        #endregion
    }
}
