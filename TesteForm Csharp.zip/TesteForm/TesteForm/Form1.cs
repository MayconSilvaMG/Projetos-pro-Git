﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TesteForm
{
    public partial class Form1 : Form
    {

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public Form1()
        {
            InitializeComponent();
        }
        
        //TextBox do RG
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.textBox3.Text)) 
                this.button1.Enabled = true;
            else
                this.button1.Enabled = false;
            
        }

        //Botão do proximo
        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.button1.Text))
                this.textBox1.Enabled = true;
            else
                this.textBox1.Enabled = false;
        }

        //TextBox do Nome
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.textBox1.Text))
                this.button1.Enabled = true;
            else
                this.button1.Enabled = false;

        }

        //TextBox do RG
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.textBox2.Text))
                this.button1.Enabled = true;
            else
                this.button1.Enabled = false;

        }
    }
}
