﻿namespace ClienteApi.Modelos
{
    public class Cliente
    {
        #region Atributos
        public long Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public bool ativo { get; set; }
        #endregion
    }
}
