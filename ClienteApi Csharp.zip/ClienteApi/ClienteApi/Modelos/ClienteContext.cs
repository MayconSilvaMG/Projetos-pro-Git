﻿using Microsoft.EntityFrameworkCore;

namespace ClienteApi.Modelos
{
    public class ClienteContext : DbContext
    {
        public ClienteContext(DbContextOptions<ClienteContext> options)
                : base(options)
        
        {
        }

        public DbSet<Cliente> ClienteItems { get; set; }
        
    }
}
