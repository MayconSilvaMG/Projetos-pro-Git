﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VamosSomar
{
    class Program
    {
        static void Main(string[] args)
        {
         int ValorA, ValorB;
         int Div, Mult, Soma, Sub;
         
         //Cores para o console.
            Console.BackgroundColor = ConsoleColor.Red;
            Console.ForegroundColor = ConsoleColor.Black;
            
         //Valor de A e conversão para Inteiro.
            Console.WriteLine("Olá Usuário, vamos somar!!");
            Console.Write("Digite o valor para A: ");
                ValorA = Convert.ToInt16 (Console.ReadLine());

         //Valor de B e conversão para Inteiro.
            Console.Write("Digite o valor para B: ");
                ValorB = Convert.ToInt16(Console.ReadLine());
            
            //Operações númericas
                Mult = ValorA * ValorB;
                Div = ValorA / ValorB;
                Soma = ValorA + ValorB;
                Sub = ValorA - ValorB;

            //Resultado das operações 
            Console.WriteLine();
            Console.WriteLine("O valor de " + ValorA + "+" + ValorB + " é " + Soma);
            Console.WriteLine("O valor de " + ValorA + "-" + ValorB + " é " + Sub);
            Console.WriteLine("O valor de " + ValorA + "x" + ValorB + " é " + Mult);
            Console.WriteLine("O valor de " + ValorA + "/" + ValorB + " é " + Div);
            Console.ReadLine();
            


        }
    }
}
