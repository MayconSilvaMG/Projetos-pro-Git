package com.tdeluiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class SegundaTela extends AppCompatActivity {

    TextView TxtAltura, TxtPeso;
    Button BtnConverte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_tela);

        setTitle("Calculo IMC");
        final float[] imc = new float[1];
        TxtAltura = findViewById(R.id.txtAltura);
        TxtPeso = findViewById(R.id.txtPeso);

        //Botao para somar o IMC
        BtnConverte = findViewById(R.id.btnConverte);
        BtnConverte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText EdtPeso = (EditText) findViewById(R.id.edtPeso);
                EditText EdtAltura = (EditText) findViewById(R.id.edtAltura);
                EditText EdtDescricao = (EditText) findViewById(R.id.edtDescricao);
                EditText EdtResultado = (EditText) findViewById(R.id.edtResultado);

                int Peso = Integer.parseInt(EdtPeso.getText().toString());
                float Altura = Float.parseFloat(EdtAltura.getText().toString());

                imc[0] = Peso / (Altura * Altura);

                if (imc[0]<18.5){
                    EdtResultado.setText(imc[0]+"");
                    EdtDescricao.setText("Baixo Peso");
                }else {
                    if (imc[0]<25){
                        EdtResultado.setText(imc[0]+"");
                        EdtDescricao.setText("Continue assim, seu peso esta adequado");
                    }
                 else {
                        if (imc[0]<30){
                            EdtResultado.setText(imc[0]+"");
                            EdtDescricao.setText("Cuidado, você está com sobrepeso");
                        }

                else {
                            EdtResultado.setText(imc[0]+"");
                            EdtDescricao.setText("Urgente, você está obeso");
                        }
            } } }
        });
        //Botao de voltar
        Button BotaoVoltar = (Button) findViewById(R.id.btnRetornar);
        BotaoVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}