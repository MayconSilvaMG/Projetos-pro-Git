package com.tdeluiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class Dado extends AppCompatActivity {

    Button BotaoVolta, BtnSorteio;
    ImageView ImgUm,ImgDois,ImgTres,ImgQuatro,ImgCinco,ImgSeis;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dado);

        setTitle("Jogo do Dado");

        BotaoVolta=findViewById(R.id.btnVolta);
        BtnSorteio=findViewById(R.id.btnSorteio);
        ImgUm=findViewById(R.id.imgUm);
        ImgDois=findViewById(R.id.imgDois);
        ImgTres=findViewById(R.id.imgTres);
        ImgQuatro=findViewById(R.id.imgQuatro);
        ImgCinco=findViewById(R.id.imgCinco);
        ImgSeis=findViewById(R.id.imgSeis);


        BotaoVolta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    public void Jogar(View view){
        int Sorteio;

        Random random = new Random();
        Sorteio = random.nextInt(6);

        if (Sorteio == 0){
            ImgUm.setVisibility(View.VISIBLE);
            ImgDois.setVisibility(View.INVISIBLE);
            ImgTres.setVisibility(View.INVISIBLE);
            ImgQuatro.setVisibility(View.INVISIBLE);
            ImgCinco.setVisibility(View.INVISIBLE);
            ImgSeis.setVisibility(View.INVISIBLE);
        }
        if (Sorteio == 1){
            ImgUm.setVisibility(View.INVISIBLE);
            ImgDois.setVisibility(View.VISIBLE);
            ImgTres.setVisibility(View.INVISIBLE);
            ImgQuatro.setVisibility(View.INVISIBLE);
            ImgCinco.setVisibility(View.INVISIBLE);
            ImgSeis.setVisibility(View.INVISIBLE);
        }
        if (Sorteio == 2){
            ImgUm.setVisibility(View.INVISIBLE);
            ImgDois.setVisibility(View.INVISIBLE);
            ImgTres.setVisibility(View.VISIBLE);
            ImgQuatro.setVisibility(View.INVISIBLE);
            ImgCinco.setVisibility(View.INVISIBLE);
            ImgSeis.setVisibility(View.INVISIBLE);
        }
        if (Sorteio == 3){
            ImgUm.setVisibility(View.INVISIBLE);
            ImgDois.setVisibility(View.INVISIBLE);
            ImgTres.setVisibility(View.INVISIBLE);
            ImgQuatro.setVisibility(View.VISIBLE);
            ImgCinco.setVisibility(View.INVISIBLE);
            ImgSeis.setVisibility(View.INVISIBLE);
        }
        if (Sorteio == 4){
            ImgUm.setVisibility(View.INVISIBLE);
            ImgDois.setVisibility(View.INVISIBLE);
            ImgTres.setVisibility(View.INVISIBLE);
            ImgQuatro.setVisibility(View.INVISIBLE);
            ImgCinco.setVisibility(View.VISIBLE);
            ImgSeis.setVisibility(View.INVISIBLE);
        }
        if (Sorteio == 5){
            ImgUm.setVisibility(View.INVISIBLE);
            ImgDois.setVisibility(View.INVISIBLE);
            ImgTres.setVisibility(View.INVISIBLE);
            ImgQuatro.setVisibility(View.INVISIBLE);
            ImgCinco.setVisibility(View.INVISIBLE);
            ImgSeis.setVisibility(View.VISIBLE);
        }
    }
}