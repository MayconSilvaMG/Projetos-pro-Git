package com.tdeluiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button BotaoImc,BotaoFinalizar,BotaoDado,BotaoConversor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle ("MENU");

        BotaoImc=findViewById(R.id.btnImc);
        BotaoFinalizar=findViewById(R.id.btnFecharApp);
        BotaoDado=findViewById(R.id.btnDado);
        BotaoConversor=findViewById(R.id.btnConversor);

        BotaoFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        BotaoImc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent segundaTela=new Intent(getApplicationContext(), SegundaTela.class);
                startActivity(segundaTela);
            }
        });

        BotaoDado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent dado=new Intent(getApplicationContext(), Dado.class);
                startActivity(dado);
            }
        });

        BotaoConversor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent conversor=new Intent(getApplicationContext(), Conversor.class);
                startActivity(conversor);
            }
        });
    }
}