package com.tdeluiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DecimalFormat;

public class Conversor extends AppCompatActivity {

    Button BotaoRetornar, BtnConverter;
    TextView TxtResult;
    EditText EdtValorEntrada;
    ImageView ImgDollar;
    String Resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversor);

        setTitle("Dolar tá CARO!");

        BotaoRetornar=findViewById(R.id.btnVoltar);
        BtnConverter=findViewById(R.id.btnConverter);
        TxtResult=findViewById(R.id.txtResult);
        EdtValorEntrada=findViewById(R.id.edtValorEntrada);
        ImgDollar=findViewById(R.id.imgDollar);

        BotaoRetornar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        BtnConverter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double VlrReal=Double.parseDouble(EdtValorEntrada.getText().toString());

                double ResultD= VlrReal * 0.19;

                DecimalFormat  formatador=new DecimalFormat("0.00");
                Resultado=formatador.format(ResultD);
                    TxtResult.setText(String.valueOf(ResultD));

                    ImgDollar.setVisibility(View.VISIBLE);
            }
        });
    }
}