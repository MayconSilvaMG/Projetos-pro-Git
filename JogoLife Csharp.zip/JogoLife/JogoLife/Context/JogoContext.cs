﻿using Microsoft.EntityFrameworkCore;
using JogoLife.Models;

namespace JogoLife.Dados
{
    public class JogoContext : DbContext
    {
        public JogoContext(DbContextOptions<JogoContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Jogo>()
                .HasKey(ac => new { ac.Id, ac.Desenvolvedor, ac.Genero, ac.Nome }) ;

            modelBuilder.Entity<Adm>()
            .HasKey(ac => new { ac.Id, });
        }

        public DbSet<Jogo> Jogos { get; set; }
        public DbSet<Adm> Adms { get; set; }
    }
}
