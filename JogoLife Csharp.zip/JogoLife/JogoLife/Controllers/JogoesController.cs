﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using JogoLife.Dados;
using JogoLife.Models;

namespace JogoLife.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JogoesController : ControllerBase
    {
        private readonly JogoContext _context;

        public JogoesController(JogoContext context)
        {
            _context = context;
        }

        // GET: api/Jogoes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Jogo>>> GetJogos()
        {
            return await _context.Jogos.ToListAsync();
        }

        // GET: api/Jogoes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Jogo>> GetJogo(string id)
        {
            var jogo = await _context.Jogos.FindAsync(id);

            if (jogo == null)
            {
                return NotFound();
            }

            return jogo;
        }

        // PUT: api/Jogoes/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutJogo(string id, Jogo jogo)
        {
            if (id != jogo.Desenvolvedor)
            {
                return BadRequest();
            }

            _context.Entry(jogo).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!JogoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Jogoes
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Jogo>> PostJogo(Jogo jogo)
        {
            _context.Jogos.Add(jogo);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (JogoExists(jogo.Desenvolvedor))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetJogo", new { id = jogo.Desenvolvedor }, jogo);
        }

        // DELETE: api/Jogoes/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Jogo>> DeleteJogo(string id)
        {
            var jogo = await _context.Jogos.FindAsync(id);
            if (jogo == null)
            {
                return NotFound();
            }

            _context.Jogos.Remove(jogo);
            await _context.SaveChangesAsync();

            return jogo;
        }

        private bool JogoExists(string id)
        {
            return _context.Jogos.Any(e => e.Desenvolvedor == id);
        }
    }
}
