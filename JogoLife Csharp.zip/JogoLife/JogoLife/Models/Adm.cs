﻿using System.Collections.Generic;

namespace JogoLife.Models
{
    public class Adm
    {
        public int Id { get; set; }
    }
}
