﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VamosSomar
{
    class Program
    {
        static void Main(string[] args)
        {
            int ValorA, ValorB;

            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.Yellow;

            Console.WriteLine("Vamos somar!!!");
            Console.Write("Digite o Valor para A: ");
            ValorA = Convert.ToInt16 (Console.ReadLine());

            Console.Write("Digite o Valor para B: ");
            ValorB = Convert.ToInt16(Console.ReadLine());

            int resultado = ValorA + ValorB;

            Console.WriteLine();
            Console.WriteLine("O resultado da soma: " + ValorA + " + " + ValorB + " é: " + resultado);
            Console.ReadLine();

        }
    }
}
